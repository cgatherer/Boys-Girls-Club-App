import React, {Component} from 'react';
import {Map, InfoWindow, Marker, GoogleApiWrapper} from 'google-maps-react';


// Create Map
export class Container extends React.Component {
  render() {
    if (!this.props.loaded) {
      return <div>Loading...</div>
    }

    const style = {
      width: '100vw',
      height: '90vh'
    }

    // var points = [
    //     { lat: 42.02, lng: -77.01 },
    //     { lat: 42.03, lng: -77.02 },
    //     { lat: 41.03, lng: -77.04 },
    //     { lat: 42.05, lng: -77.02 }
    // ]
    //
    // var bounds = new this.props.google.maps.LatLngBounds();
    //
    // for (var i = 0; i < points.length; i++) {
    //   bounds.extend(points[i]);
    // }

    return (
      <div style={style}>
        <Map google={this.props.google}
          zoom={13}
          initialCenter={{
            lat: 39.3643,
            lng: -74.4229
          }}>
            <Marker onClick={this.onMarkerClick}
              title={'The marker`s title will appear as a tooltip.'}
              name={'Salvation Army'}
              position={{lat: 39.3549, lng: -74.4429}} />

            <Marker onClick={this.onMarkerClick}
              title={'The marker`s title will appear as a tooltip.'}
              name={'Turning Point Day Center for Homeless'}
              position={{lat: 39.3656463, lng: -74.43630430000002}} />

            <Marker onClick={this.onMarkerClick}
              title={'The marker`s title will appear as a tooltip.'}
              name={'Zion Redevelopment'}
              position={{lat: 39.366664, lng: -74.41770839999998}} />

            <Marker onClick={this.onMarkerClick}
              title={'The marker`s title will appear as a tooltip.'}
              name={'AC Rescue Mission'}
              position={{lat: 39.3650061, lng: -74.44001409999998}} />
          </Map>
      </div>
    )
  }
}

const WrappedMap = GoogleApiWrapper({
  apiKey: 'AIzaSyAIEVY_I_PCQD8mGdWo4IzYaoFDaCN3kCI'
})(Container);

module.exports = WrappedMap;
