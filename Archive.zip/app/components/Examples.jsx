var React = require('react');

var Examples = React.createClass({
  render: function () {
    return (
      <div className="cd-examples">
        <h3>Examples Component</h3>
      </div>
    )
  }
});

module.exports = Examples;
